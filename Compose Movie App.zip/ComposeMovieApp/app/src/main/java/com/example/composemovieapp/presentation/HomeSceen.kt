package com.example.composemovieapp.presentation


import android.annotation.SuppressLint
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.composemovieapp.domain.MovieViewModel
import com.example.composemovieapp.model.MoviesItem

@SuppressLint("SuspiciousIndentation")
@Composable
fun HomeScreen(
    navController: NavController,
    movieViewModel: MovieViewModel = hiltViewModel()
) {
    val movieList by movieViewModel.getList.collectAsState()

        Column {
            BodyView(navController = navController, movieList = movieList)
        }
}


@Composable
fun BodyView(
    modifier: Modifier = Modifier,
    navController: NavController,
    movieList: List<MoviesItem>
) {
    Box(
        modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
            .background(Color.White)
            .padding(top = 30.dp)

    ) {

        Column {

            movieListSection(movies = movieList, navController = navController)

        }

    }
}



@Composable
fun movieListSection(
    movies: List<MoviesItem>,
    navController: NavController
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
    ) {

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(start = 7.5.dp, end = 7.5.dp, bottom = 100.dp),
            modifier = Modifier
                .fillMaxSize()
        ) {
            items(movies.size) {
                MovieListItem(movie = movies[it], navController = navController)
            }
        }
    }

}


@Composable
fun MovieListItem(
    movie: MoviesItem,
    navController: NavController
) {

    //val image = rememberAsyncImagePainter(model = games.thumbnail)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(146.dp)
            .padding(horizontal = 10.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(10.dp))
            .shadow(elevation = 1.5.dp)
            .clickable {
                navController.navigate("movie_details/${movie.id}")
            }
    ) {

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxSize()
        ) {

            AsyncImage(
                model = movie.image,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
                    .padding(top = 12.dp, start = 12.dp, end = 12.dp)
            )

            Text(
                text = movie.name,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                modifier = Modifier
                    .height(24.dp)
                    .padding(horizontal = 12.dp)
            )
        }

    }
}




