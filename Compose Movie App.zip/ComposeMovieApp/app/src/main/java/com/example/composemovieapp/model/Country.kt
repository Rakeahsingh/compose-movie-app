package com.example.composemovieapp.model

data class Country(
    val code: String,
    val name: String,
    val timezone: String
)