package com.example.composemovieapp.model

data class DvdCountry(
    val code: String,
    val name: String,
    val timezone: String
)