package com.example.composemovieapp.model

data class Nextepisode(
    val href: String
)