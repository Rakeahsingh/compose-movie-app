package com.example.composemovieapp.presentation

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.example.composemovieapp.domain.MovieDetailsViewModel
import com.example.composemovieapp.ui.theme.gray


@Composable
fun movieDetailsScreen(
    navController: NavController,
    movieDetailsViewModel: MovieDetailsViewModel = hiltViewModel()
){

    val movie by movieDetailsViewModel.movie.collectAsState()

    Box(
        modifier = Modifier
            .background(gray)
            .fillMaxSize()
    ){
        Column {

           Icon(
               imageVector = Icons.Default.ArrowBack, contentDescription = "Arrow Back",
               tint = Color.White,
               modifier = Modifier
                   .padding(10.dp)
                   .size(24.dp)
                   .clickable {
                       navController.popBackStack()
                   }
           )

            AsyncImage(
                model = movie?.image,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(115.dp)
                    .padding(start = 12.dp, end = 12.dp)
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 20.dp)
                    .clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                    .background(Color.White)
            ){

                Text(
                    text = movie?.name.toString(),
                    color = Color.Red,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .padding(top = 12.dp, start = 100.dp)
                )

                Text(
                    text = movie?.rating.toString(),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .padding(top = 12.dp, start = 100.dp)
                )

                Text(
                    text = movie?.status.toString(),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .padding(top = 12.dp, start = 100.dp)
                )

            }

        }
    }

}