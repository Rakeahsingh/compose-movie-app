package com.example.composemovieapp.model

data class Externals(
    val imdb: String,
    val thetvdb: Int,
    val tvrage: Int
)