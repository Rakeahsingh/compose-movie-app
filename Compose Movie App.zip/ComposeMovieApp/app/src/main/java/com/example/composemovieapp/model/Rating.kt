package com.example.composemovieapp.model

data class Rating(
    val average: Double
)