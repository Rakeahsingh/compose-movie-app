package com.example.composemovieapp.model

class Movies : ArrayList<MoviesItem>()