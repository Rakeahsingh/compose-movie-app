package com.example.composemovieapp.model

data class Previousepisode(
    val href: String
)