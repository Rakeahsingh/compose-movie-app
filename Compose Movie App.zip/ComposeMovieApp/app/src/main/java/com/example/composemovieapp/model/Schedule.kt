package com.example.composemovieapp.model

data class Schedule(
    val days: List<String>,
    val time: String
)