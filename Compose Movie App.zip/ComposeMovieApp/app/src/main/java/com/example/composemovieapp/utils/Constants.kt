package com.example.composemovieapp.utils

object Constants {

    const val BASE_URL = "https://api.tvmaze.com/"
    const val END_POINT = "shows"
    const val END_POINT_GAME = "show"

}