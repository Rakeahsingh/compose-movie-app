package com.example.composemovieapp.data


import com.example.composemovieapp.model.MoviesItem
import com.example.composemovieapp.utils.Constants.END_POINT
import com.example.composemovieapp.utils.Constants.END_POINT_GAME
import retrofit2.http.GET
import retrofit2.http.Query

interface MovieApi {

    @GET(END_POINT)
    suspend fun getMovies(): List<MoviesItem>

    @GET(END_POINT_GAME)
    suspend fun getMovieById(
        @Query("id") id : Int
    ) : MoviesItem
}