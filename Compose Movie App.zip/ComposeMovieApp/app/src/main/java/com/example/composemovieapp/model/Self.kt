package com.example.composemovieapp.model

data class Self(
    val href: String
)